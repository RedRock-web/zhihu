package features

//user表示一个用户
type User struct {
	username    string
	password    string
	uid         string
	gender      string
	nickname    string
	introdution string
	avatar      string
}
